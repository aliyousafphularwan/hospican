<?php

	$var = "person";

?>

<div class="container">
	<script>
		
		var i = '<?php echo $var;?>';
		document.write(i);

	</script>
</div>