<div class="container">
	
	<div class="row">
		<div class="col-md-2">
			<h5> Category </h5>
			<ul>
				<li><a href="#"> Item </a></li>
			</ul>
		</div>
	</div>

</div>