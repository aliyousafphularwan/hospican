<?php

	session_unset();   
	session_destroy();
	
?>