<div class="container">
	
	<p>
		you are visiting &nbsp; <?php echo $_GET["page"];?> &nbsp; page.
	</p>

</div>