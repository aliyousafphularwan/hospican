<?php 

	if (isset($_POST['banmit'])) {
		
	}

?>